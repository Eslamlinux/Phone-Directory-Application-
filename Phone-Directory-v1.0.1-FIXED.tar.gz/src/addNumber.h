#pragma once

void addNumber();
