#pragma once
#include <string>

// Utility function to get the data file path
std::string getDataFilePath();