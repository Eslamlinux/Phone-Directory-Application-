
#include <iostream>
#include <string>


class Node{
    public:
    std::string data;
    Node* left;
    Node* right;
    Node(std::string val);
};

class filetree{
    public:
    Node *root;
    filetree();
    const bool isEmpty(Node* r);
    Node* To_insert(Node* r,std::string val);
    void To_insert(std::string val);
    void Save(Node* r);
    void SaveToFile();
    Node* MiniData(Node* r);
    Node* MiniData();
    Node* MaxmumData(Node* r);
    Node* MaxmumData();
    void SearchAndPrintAll(Node* r, const std::string& val, int& foundCount);
    void SearchAndPrintAll(const std::string& val);
    std::string SearchInsideTree(Node* r, const std::string& val);
    std::string SearchInsideTree(const std::string& val);
    Node* Delete_Contact(Node* r, std::string user_entry); 
    Node* Delete_Contact(std::string user_entry); 
    Node* Delete_All_Contacts(Node* r); 
    Node* Delete_All_Contacts(); 
    void print_preorder(Node* r);
    void print_inorder(Node* r);
    void print_postorder(Node* r);
};
extern filetree Manage_Data_Tree;
