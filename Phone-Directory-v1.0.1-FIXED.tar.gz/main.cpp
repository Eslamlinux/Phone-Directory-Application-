#include "src/setup.h"

int main(){
    setup();




    return 0;
}