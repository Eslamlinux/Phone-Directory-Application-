#pragma once

void deleteAllContacts();
