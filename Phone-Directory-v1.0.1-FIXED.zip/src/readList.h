#pragma once

void readList();
int countsize();
